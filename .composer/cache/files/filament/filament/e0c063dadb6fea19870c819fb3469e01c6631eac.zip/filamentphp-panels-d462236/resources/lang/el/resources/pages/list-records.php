<?php

return [

    'breadcrumb' => 'Λίστα',

];
